package com.example.menstrualcycletrackingapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private EditText dateEditText;
    private TextView resultTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Get references to UI elements
        Button submitButton = findViewById(R.id.submit);
        dateEditText = findViewById(R.id.date);
        resultTextView = findViewById(R.id.result);

        // Set onClickListener for submit button
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get date entered by user
                String dateStr = dateEditText.getText().toString();

                // Calculate estimated date of next period
                Calendar calendar = Calendar.getInstance();
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                try {
                    Date date = dateFormat.parse(dateStr);
                    calendar.setTime(date);
                    calendar.add(Calendar.DAY_OF_MONTH, 28); // assume 28 day cycle
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Date nextPeriodDate = calendar.getTime();

                // Display result in TextView
                DateFormat resultDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                String resultStr = "Your next period is estimated on " + resultDateFormat.format(nextPeriodDate);
                resultTextView.setText(resultStr);
            }
        });
    }
}