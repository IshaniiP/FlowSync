package com.example.menstrualcycletrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;

public class LoginActivity extends AppCompatActivity {

        private FirebaseAuth mAuth;
        private EditText mEmailField;
        private EditText mPasswordField;

        private Button loginButton;

        private Button registerButton;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
                super.onCreate(savedInstanceState);
                setContentView(R.layout.activity_login);

                // Initialize Firebase Auth
                mAuth = FirebaseAuth.getInstance();

                // Get references to UI elements
                mEmailField = findViewById(R.id.emailEditText);
                mPasswordField = findViewById(R.id.passwordEditText);
                loginButton = findViewById(R.id.loginButton);
                registerButton = findViewById(R.id.registerTextView);

                // Set onClickListener for login button
                loginButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                // Get user input
                                String email = mEmailField.getText().toString();
                                String password = mPasswordField.getText().toString();

                                // Validate user input
                                if (!validateEmail(email)) {
                                        mEmailField.setError("Please enter a valid email address");
                                        mEmailField.requestFocus();
                                        return;
                                }

                                if (!validatePassword(password)) {
                                        mPasswordField.setError("Please enter a strong password");
                                        mPasswordField.requestFocus();
                                        return;
                                }

                                // Sign in user with email and password
                                mAuth.signInWithEmailAndPassword(email, password)
                                        .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                                @Override
                                                public void onComplete(@NonNull Task<AuthResult> task) {
                                                        if (task.isSuccessful()) {
                                                                // Sign in success, update UI with the signed-in user's information
                                                                FirebaseUser user = mAuth.getCurrentUser();
                                                                Toast.makeText(LoginActivity.this, "Authentication success.",
                                                                        Toast.LENGTH_SHORT).show();
                                                                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                                                                finish();
                                                        } else {
                                                                // If sign in fails, display a message to the user.
                                                                Toast.makeText(LoginActivity.this, "Authentication failed. Please check your credentials and try again.",
                                                                        Toast.LENGTH_SHORT).show();
                                                        }
                                                }
                                        });

                // Set onClickListener for register button
                registerButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                                // Navigate user to registration screen
                                startActivity(new Intent(LoginActivity.this, RegistrationActivity.class));
                        }
                });
        }

        // Validate email address
        private boolean validateEmail(String email) {
                return Patterns.EMAIL_ADDRESS.matcher(email).matches();
        }

        // Validate password strength
        private boolean validatePassword(String password) {
                // Password should be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one special character
                String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
                return password.matches(passwordPattern);
        }
}
